
$(document).ready(function () {
    var books = []
    var format = "json"; // Default format is JSON

    var uri = 'http://localhost:8080/BooksSystem/BookAPI';

    function fetchBooks() {

        // Add format query parameter if XML is selected
        if (format === "xml") {
            uri += '?format=xml';
        }

        $.ajax({
            url: uri,
            method: 'GET',
            dataType: format,
            success: function (response) {
                // Handle the API response

                if (format === "json") {
                    books = response;
                } else if (format === "xml") {
                    // Format XML response into books array
                    books = parseXmlResponse(response);
                }

                // Generate the table rows based on the book data
                $('tbody').html(generateBookRows());

                // Delete book event handler using event delegation
                $('table').on('click', '.delete-book', function (e) {
                    e.preventDefault();
                    var bookId = $(this).data('id');

                    $.ajax({
                        url: `http://localhost:8080/BooksSystem/BookAPI?id=${bookId}`,
                        type: 'DELETE',
                        success: function () {
                            // Find the index of the book with the given ID in the books array
                            var bookIndex = books.findIndex(function (book) {
                                return book.id === bookId;
                            });
                            if (bookIndex !== -1) {
                                books.splice(bookIndex, 1);
                                $('tbody').html(generateBookRows());
                                console.log('Deleted book with ID:', bookId);
                            }
                        },
                        error: function (xhr, textStatus, error) {
                            console.log('Error deleting book:', error);
                        }
                    });


                });


                // Edit book event handler using event delegation
                $('table').on('click', '.edit-book', function (e) {
                    e.preventDefault();
                    var bookId = $(this).data('id');

                    // Find the book with the given ID
                    var book = books.find(function (book) {
                        return book.id === bookId;
                    });

                    if (book) {
                        // Populate the form fields with the book data
                        $('#editTitle').val(book.title);
                        $('#editAuthor').val(book.author);
                        $('#editDate').val(book.date);
                        $('#editGenres').val(book.genres);
                        $('#editCharacters').val(book.characters);
                        $('#editSynopsis').val(book.synopsis);

                        // Show the modal dialog
                        $('#editBookModal').modal('show');

                        // Save changes button event handler
                        $('#saveChangesBtn').off().on('click', function () {
                            // Get the updated values from the form fields
                            var updatedBook = {
                                id: book.id,
                                title: $('#editTitle').val(),
                                author: $('#editAuthor').val(),
                                date: $('#editDate').val(),
                                genres: $('#editGenres').val(),
                                characters: $('#editCharacters').val(),
                                synopsis: $('#editSynopsis').val()
                            };

                            // Send the PUT request to update the book
                            $.ajax({
                                url: 'http://localhost:8080/BooksSystem/BookAPI',
                                type: 'PUT',
                                data: JSON.stringify(updatedBook),
                                contentType: 'application/json',
                                success: function () {
                                    // Find the index of the book with the given ID in the books array
                                    var bookIndex = books.findIndex(function (b) {
                                        return b.id === bookId;
                                    });

                                    if (bookIndex !== -1) {
                                        // Update the book in the books array
                                        books[bookIndex] = updatedBook;

                                        // Regenerate the book rows and update the table
                                        $('tbody').html(generateBookRows());

                                        // Hide the modal dialog
                                        $('#editBookModal').modal('hide');

                                        console.log('Updated book with ID:', bookId);
                                    }
                                }
                            });

                        });
                    }
                });

                // Add book button event handler
                $('#addBookBtn').on('click', function () {
                    // Get the values from the form fields
                    var newBook = {
                        title: $('#newTitle').val(),
                        author: $('#newAuthor').val(),
                        date: $('#newDate').val(),
                        genres: $('#newGenres').val(),
                        characters: $('#newCharacters').val(),
                        synopsis: $('#newSynopsis').val()
                    };

                    // Send the POST request to add the new book
                    $.ajax({
                        url: 'http://localhost:8080/BooksSystem/BookAPI',
                        type: 'POST',
                        data: JSON.stringify(newBook),
                        contentType: 'application/json',
                        success: function () {
                            // Regenerate the book rows and update the table
                            // $('tbody').html(generateBookRows());


                            // Hide the modal dialog
                            $('#addBookModal').modal('hide');

                            // Clear the form fields
                            $('#newTitle').val('');
                            $('#newAuthor').val('');
                            $('#newDate').val('');
                            $('#newGenres').val('');
                            $('#newCharacters').val('');
                            $('#newSynopsis').val('');

                            console.log('Added new book:', newBook);

                            $.ajax({
                                url: 'http://localhost:8080/BooksSystem/BookAPI',
                                method: 'GET',
                                dataType: 'json',
                                success: function (response) {
                                    // Handle the API response
                                    books = response;
                                    $('tbody').html(generateBookRows());

                                }
                            });
                        }
                    });


                });
            },
            error: function (error) {
                console.error('Error fetching data from API:', error);
            }
        });


    }
    //-------------------------------------------

    // Function to generate the book rows
    function generateBookRows() {
        var rows = '';
        books.forEach(function (book) {
            rows += `
          <tr>
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.date}</td>
            <td>${book.genres}</td>
            <td>${book.characters}</td>
            <td>${book.synopsis}</td>
            <td>
              <a href="#" class="text-danger delete-book" data-id="${book.id}">
                <i class="fas fa-trash-alt"></i>
              </a>
              <a href="#" class="text-primary edit-book" data-id="${book.id}">
                <i class="fas fa-edit"></i>
              </a>
            </td>
          </tr>
        `;
        });
        return rows;
    }

    function parseXmlResponse(response) {
        var books = [];

        // Assuming the XML response contains a <books> root element
        var xmlBooks = response.getElementsByTagName('book');

        // Iterate over each <book> element and extract the necessary data
        for (var i = 0; i < xmlBooks.length; i++) {
            var xmlBook = xmlBooks[i];
            var book = {};

            // Extract the data from the XML elements
            book.id = xmlBook.getElementsByTagName('id')[0].textContent;
            book.title = xmlBook.getElementsByTagName('title')[0].textContent;
            book.author = xmlBook.getElementsByTagName('author')[0].textContent;
            book.date = xmlBook.getElementsByTagName('date')[0].textContent;
            book.genres = xmlBook.getElementsByTagName('genres')[0].textContent;
            book.characters = xmlBook.getElementsByTagName('characters')[0].textContent;
            book.synopsis = xmlBook.getElementsByTagName('synopsis')[0].textContent;

            // Add the book object to the books array
            books.push(book);
        }

        return books;
    }

    // Event handler for format select change
  $('#formatSelect').change(function () {
    format = $(this).val(); // Update the selected format
    fetchBooks(); // Fetch books based on the selected format
  });

    fetchBooks()

});
